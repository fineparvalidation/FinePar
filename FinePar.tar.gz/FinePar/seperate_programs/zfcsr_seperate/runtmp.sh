make
mkdir -p res
#a=`ls ~/zf/spmv/1*/`
#programdir="/home/pacman/zf/spmv/1matrix_small/"

a=`ls ~/zf/spmv/2*/`
programdir="/home/pacman/zf/spmv/2m*/"
resdir="/home/pacman/zf/wubo/apu_corun/zfcsr/res3threadslarge64/"
for i in $a
do
  echo "This is $i"
  name=`echo $i|sed 's/.mtx//g'`
  #echo $name
  ./spmv $programdir$i | tee  $resdir/$name.txt
  sleep 5
done

