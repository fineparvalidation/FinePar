 make
 sleep 2
 ./spmv ~/zf/graph500/old/graph500-2.1.4/seq-csr/matrix20/matrxtest.txt  0
 sleep 2
 ./spmv ~/zf/graph500/old/graph500-2.1.4/seq-csr/matrix20/matrxtest.txt 10
 sleep 2
 ./spmv ~/zf/graph500/old/graph500-2.1.4/seq-csr/matrix20/matrxtest.txt 20
 sleep 2
 ./spmv ~/zf/graph500/old/graph500-2.1.4/seq-csr/matrix20/matrxtest.txt 30
 sleep 2
 ./spmv ~/zf/graph500/old/graph500-2.1.4/seq-csr/matrix20/matrxtest.txt 40
 sleep 2
 ./spmv ~/zf/graph500/old/graph500-2.1.4/seq-csr/matrix20/matrxtest.txt 50
 sleep 2
 ./spmv ~/zf/graph500/old/graph500-2.1.4/seq-csr/matrix20/matrxtest.txt 60
 sleep 2
 ./spmv ~/zf/graph500/old/graph500-2.1.4/seq-csr/matrix20/matrxtest.txt 70
 sleep 2
 ./spmv ~/zf/graph500/old/graph500-2.1.4/seq-csr/matrix20/matrxtest.txt 80
 sleep 2
 ./spmv ~/zf/graph500/old/graph500-2.1.4/seq-csr/matrix20/matrxtest.txt 90
 sleep 2
 ./spmv ~/zf/graph500/old/graph500-2.1.4/seq-csr/matrix20/matrxtest.txt 100
