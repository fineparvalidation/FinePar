 make clean; make
 sleep 3
 ./spmv ~/zf/graph500/old/graph500-2.1.4/seq-csr/matrix20/matrxtest.txt 
 sleep 3
 
