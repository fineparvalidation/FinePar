make;

./spmv ~/zf/spmv/2matrix_mediumsize/circuit5M.mtx 0
./spmv ~/zf/spmv/2matrix_mediumsize/circuit5M.mtx 10
./spmv ~/zf/spmv/2matrix_mediumsize/circuit5M.mtx 20
./spmv ~/zf/spmv/2matrix_mediumsize/circuit5M.mtx 30
./spmv ~/zf/spmv/2matrix_mediumsize/circuit5M.mtx 40
./spmv ~/zf/spmv/2matrix_mediumsize/circuit5M.mtx 50
./spmv ~/zf/spmv/2matrix_mediumsize/circuit5M.mtx 60
./spmv ~/zf/spmv/2matrix_mediumsize/circuit5M.mtx 70
./spmv ~/zf/spmv/2matrix_mediumsize/circuit5M.mtx 80
./spmv ~/zf/spmv/2matrix_mediumsize/circuit5M.mtx 90
./spmv ~/zf/spmv/2matrix_mediumsize/circuit5M.mtx 100
