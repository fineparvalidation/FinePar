make; ./spmv ~/zf/spmv/2matrix_mediumsize/circuit5M.mtx 

