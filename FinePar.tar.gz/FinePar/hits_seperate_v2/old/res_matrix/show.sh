 a=`ls *.txt`;for i in $a; do echo "########$i"; cat $i | grep ]; done
